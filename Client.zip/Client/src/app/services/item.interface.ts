export class Item {
  readonly name: string;
  readonly price: number;
}
