import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from "@angular/forms";
import { AuthService } from './../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {

  SignupForm: FormGroup;

  constructor(
    public fb: FormBuilder,
    public authService: AuthService,
    public router: Router
    ) { }

  ngOnInit() {

    this.reactiveForm()

  }


  reactiveForm() {
    this.SignupForm = this.fb.group({
      name: [''],
      email: [''],
      mobile: [''],
      password: ['']      
    })
  }

  submitForm() {
    this.authService.signUp(this.SignupForm.value).subscribe((res) => {
      console.log("Signup Value", this.SignupForm.value)
      console.log("Res", res)
  
      if (res.result) {
        console.log(res)
        this.SignupForm.reset()
        this.router.navigate(['/login']);
      }
    })
}
}