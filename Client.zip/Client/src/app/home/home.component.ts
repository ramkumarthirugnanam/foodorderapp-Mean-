import { Component, OnInit,NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Item } from './../services/item.interface';
import {AuthService } from './../services/auth.service'
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  imageSrc = 'assets/Idly'  
  imageAlt = 'Idly'

  ImageSrc = 'assets/pizza.png'  
  ImageAlt = 'pizza'

  

  items: Item [] = [{
    name: 'Pizza',
    price: 199
  },
  {
    name: 'Idly',
    price: 25
  }];
  
  itemSubmitted = false;
  itemForm: FormGroup;
  Items:any = [];

  constructor(private formBuilder: FormBuilder,
              private authService: AuthService) { }

  addToCart() {
    window.alert('Added');
  }

  ngOnInit() {

    

    this.itemForm = this.formBuilder.group({
      name: ['', Validators.required], // Name is required
      price: ['', [Validators.required, Validators.min(0)]] // Price is required and must be a positive number
    });
  }

  get getItemForm() {
    return this.itemForm.controls;
  }

  addNewItem() {
    this.itemSubmitted = true;
    if (!this.itemForm.valid) {
      return false;
    } else {
      this.authService.addItem(this.itemForm.value).subscribe(
        (res) => {
          console.log("this.userForm.value..",this.itemForm.value,res)
          console.log('userForm successfully created!')
        }, (error) => {
          console.log(error);
        });
    }
  }

  removeItem(item, index) {
    if(window.confirm('Are you sure?')) {
        this.authService.deleteItem(item._id).subscribe((data) => {
          this.Items.splice(index, 1);
        }
      )
    }
  }
  }

