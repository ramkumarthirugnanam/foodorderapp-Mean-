import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/interfaces/Ilogin';
import { LoginService } from 'src/app/services/login.service';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder ,Validators} from "@angular/forms";
import { AuthService } from './../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  SigninForm: FormGroup;


  user = {} as User;
  constructor(private loginService: LoginService,
              public fb: FormBuilder,
              public authService: AuthService,
              private router: Router) {

    this.SigninForm = this.fb.group({
      email: ['',[Validators.required]],
      password: ['',[Validators.required]]
    })
   }

  ngOnInit() {
  }
  loginForm(){
console.log("this.SigninForm.value...",this.SigninForm.value)
    if(this.authService.signIn(this.SigninForm.value)){
      this.router.navigate(['/home']);

    }
  }

}
