export interface User {
    mobileNumber: string;
}